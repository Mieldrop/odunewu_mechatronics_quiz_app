# Mechatronics Quiz App
# A beginner-friendly Python multiple-choice quiz with difficulty levels.

# Questions are stored in a list of dictionaries.
# Each question has a difficulty, question text, options, and correct answer.
questions = [
    {
        "level": "easy",
        "question": "What does CPU stand for?",
        "options": ["A. Central Processing Unit", "B. Computer Personal Unit",
                    "C. Control Program Utility", "D. Central Power Utility"],
        "answer": "A",
        "explanation": "CPU means Central Processing Unit. It processes instructions in a computer."
    },
    {
        "level": "easy",
        "question": "Which component stores electrical energy?",
        "options": ["A. Resistor", "B. Capacitor", "C. Switch", "D. Fuse"],
        "answer": "B",
        "explanation": "A capacitor stores energy in an electric field."
    },
    {
        "level": "easy",
        "question": "Which unit is used to measure electric current?",
        "options": ["A. Volt", "B. Ohm", "C. Ampere", "D. Watt"],
        "answer": "C",
        "explanation": "Electric current is measured in amperes (A)."
    },
    {
        "level": "medium",
        "question": "What is the unit of electrical resistance?",
        "options": ["A. Ohm", "B. Ampere", "C. Joule", "D. Tesla"],
        "answer": "A",
        "explanation": "Electrical resistance is measured in ohms (Ω)."
    },
    {
        "level": "medium",
        "question": "Which device converts electrical energy into mechanical motion?",
        "options": ["A. Transformer", "B. Electric motor", "C. Diode", "D. Capacitor"],
        "answer": "B",
        "explanation": "An electric motor converts electrical energy into mechanical energy."
    },
    {
        "level": "medium",
        "question": "What is the main function of a sensor in a mechatronic system?",
        "options": ["A. To detect or measure a physical quantity",
                    "B. To store programs permanently",
                    "C. To increase wire length",
                    "D. To supply fuel"],
        "answer": "A",
        "explanation": "A sensor detects or measures a physical condition and provides information to a system."
    },
    {
        "level": "hard",
        "question": "Which control system uses feedback to correct its output?",
        "options": ["A. Open-loop system", "B. Closed-loop system",
                    "C. Manual-only system", "D. Passive system"],
        "answer": "B",
        "explanation": "A closed-loop control system uses feedback to compare output with the desired value."
    },
    {
        "level": "hard",
        "question": "In a simple series circuit, what happens to the current through each component?",
        "options": ["A. It is different in every component",
                    "B. It is the same through every component",
                    "C. It is always zero",
                    "D. It depends only on wire colour"],
        "answer": "B",
        "explanation": "The same current flows through all components connected in series."
    },
    {
        "level": "hard",
        "question": "Which electronic component allows current to flow mainly in one direction?",
        "options": ["A. Diode", "B. Resistor", "C. Inductor", "D. Relay coil"],
        "answer": "A",
        "explanation": "A diode is designed to conduct mainly in one direction."
    }
]


def choose_difficulty():
    """Ask the user to select a difficulty and return the selection."""
    print("\nChoose your difficulty:")
    print("1. Easy")
    print("2. Medium")
    print("3. Hard")

    choices = {"1": "easy", "2": "medium", "3": "hard"}

    while True:
        choice = input("Enter 1, 2, or 3: ").strip()
        if choice in choices:
            return choices[choice]
        print("Invalid choice. Please enter 1, 2, or 3.")


def get_questions(level):
    """Return all questions that match the selected difficulty."""
    return [question for question in questions if question["level"] == level]


def ask_question(question, number):
    """Display one question, validate the answer, and return True or False."""
    print(f"\nQuestion {number}: {question['question']}")
    for option in question["options"]:
        print(option)

    while True:
        answer = input("Your answer (A, B, C or D): ").strip().upper()
        if answer in ["A", "B", "C", "D"]:
            break
        print("Invalid answer. Please enter A, B, C, or D.")

    if answer == question["answer"]:
        print("Correct!")
        return True

    print(f"Incorrect. The correct answer is {question['answer']}.")
    print(f"Explanation: {question['explanation']}")
    return False


def calculate_percentage(score, total):
    """Calculate and return the quiz score as a percentage."""
    if total == 0:
        return 0
    return (score / total) * 100


def show_result(score, total, wrong_answers):
    """Display the final score and review questions answered incorrectly."""
    percentage = calculate_percentage(score, total)

    print("\n" + "=" * 40)
    print("             QUIZ RESULT")
    print("=" * 40)
    print(f"Correct answers: {score}/{total}")
    print(f"Percentage: {percentage:.1f}%")

    if percentage >= 80:
        print("Grade: Excellent! Keep it up.")
    elif percentage >= 60:
        print("Grade: Good effort. Keep practising.")
    elif percentage >= 40:
        print("Grade: Fair. More revision will help.")
    else:
        print("Grade: Needs improvement. Don't give up!")

    # Extra feature: review incorrect answers after the quiz.
    if wrong_answers:
        print("\nREVIEW OF INCORRECT ANSWERS")
        for item in wrong_answers:
            print(f"\nQuestion: {item['question']}")
            print(f"Correct answer: {item['answer']}")
            print(f"Explanation: {item['explanation']}")
    else:
        print("\nExcellent! You answered every question correctly.")


def run_quiz():
    """Run the quiz from start to finish."""
    print("=" * 40)
    print("       WELCOME TO MECHATRONICS QUIZ")
    print("=" * 40)
    print("Test your knowledge of basic mechatronics.")

    level = choose_difficulty()
    selected_questions = get_questions(level)

    score = 0
    wrong_answers = []

    for number, question in enumerate(selected_questions, start=1):
        is_correct = ask_question(question, number)
        if is_correct:
            score += 1
        else:
            wrong_answers.append(question)

    show_result(score, len(selected_questions), wrong_answers)
    print("\nThank you for using the Mechatronics Quiz App!")


# This line starts the program when the Python file is run.
if __name__ == "__main__":
    run_quiz()
